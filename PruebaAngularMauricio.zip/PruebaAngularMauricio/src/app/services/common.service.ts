import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  constructor(private http:HttpClient) { }

  public obtenerDatosPersonajes(tipoCasa:string): Observable<any[]> {
    return this.http.get<any[]>(`http://hp-api.herokuapp.com/api/characters/house/${tipoCasa}`);
  }

  public obtenerDatosEstudiantes(): Observable<any[]> {
    return this.http.get<any[]>('http://hp-api.herokuapp.com/api/characters/students');
  }

  public obtenerDatosProfesores(): Observable<any[]> {
    return this.http.get<any[]>('http://hp-api.herokuapp.com/api/characters/staff');
  }


}

