export interface Solicitud {
    nombres: string;
    patrouns: string;
    age: string;    
}