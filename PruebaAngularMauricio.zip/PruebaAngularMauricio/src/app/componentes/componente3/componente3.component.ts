import { Component, OnInit } from '@angular/core';
import { finalize } from 'rxjs/operators';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-componente3',
  templateUrl: './componente3.component.html',
  styleUrls: ['./componente3.component.css']
})
export class Componente3Component implements OnInit {

  displayedColumns: string[] = ['name', 'patronus', 'dateOfBirth', 'image'];
  dataSource:any=[];
  mostrar:boolean=false;

  constructor(private commonService:CommonService) { }

  ngOnInit(): void {
    this.obtenerDatos();
  }

  obtenerDatos() {
    this.commonService.obtenerDatosProfesores().pipe(
      finalize(() => {
        console.log('Servicio completado correctamente');        
      }
      )).subscribe(resp => {        
        this.dataSource = resp;  
        this.mostrar = true;   
        console.log(this.dataSource);
      });
  }
}
