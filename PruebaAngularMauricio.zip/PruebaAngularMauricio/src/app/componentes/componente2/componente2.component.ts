import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { finalize } from 'rxjs/operators';
import { CommonService } from 'src/app/services/common.service';
import { CrearsolititudComponent } from './crearsolititud/crearsolititud.component';

@Component({
  selector: 'app-componente2',
  templateUrl: './componente2.component.html',
  styleUrls: ['./componente2.component.css']
})
export class Componente2Component implements OnInit {

  displayedColumns: string[] = ['name', 'patronus', 'dateOfBirth', 'image'];
  dataSource:any=[];
  mostrar:boolean=false;

  constructor(private commonService:CommonService,
    public dialog: MatDialog) { }
  
  ngOnInit(): void {
    this.obtenerDatos();
  }
  obtenerDatos() {
    this.commonService.obtenerDatosEstudiantes().pipe(
      finalize(() => {
        console.log('Servicio completado correctamente');        
      }
      )).subscribe(resp => {        
        this.dataSource = resp;  
        this.mostrar = true;   
        //console.log(this.dataSource);
      });
  }

  onCXP() {    

    const dialog = this.dialog.open(CrearsolititudComponent, {
      width: "600px",
      height: "auto",
      maxHeight: "650px",
      data: {},
    });
  }
  

}
