import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { finalize } from 'rxjs/operators';
import { Solicitud } from 'src/app/models/modelo.interface';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-crearsolititud',
  templateUrl: './crearsolititud.component.html',
  styleUrls: ['./crearsolititud.component.css']
})
export class CrearsolititudComponent implements OnInit {

  public registro: any = [];
  public data:any = [];
  datos:any=[];
  

  constructor(private commonService:CommonService,
    private dialogRef: MatDialogRef<CrearsolititudComponent>) { }

  public ingresoForm = new FormGroup({
    nombres: new FormControl('', Validators.required),    
    patrouns: new FormControl('', Validators.required),
    age: new FormControl('', Validators.required)    
  });


  ngOnInit(): void {
    
  }

  registrar(modelo: any) {
    this.data = sessionStorage.getItem('usuarios');
    
    if(this.data === null){
      this.data = [];
    }else{
      this.datos = JSON.parse(this.data);
    }
    
    this.datos.push(modelo); 
    sessionStorage.setItem('usuarios', JSON.stringify(this.datos));
    this.limpiarformulario();
     
  }
  limpiarformulario() {
    this.ingresoForm.patchValue({
      nombres: '',
    });
    this.ingresoForm.patchValue({
      patrouns: '',
    });
    this.ingresoForm.patchValue({
      age: '',
    });

  }

  onSalir() {
    this.dialogRef.close();
  }

}
