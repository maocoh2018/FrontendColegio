import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CrearsolititudComponent } from './crearsolititud.component';

describe('CrearsolititudComponent', () => {
  let component: CrearsolititudComponent;
  let fixture: ComponentFixture<CrearsolititudComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CrearsolititudComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CrearsolititudComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
