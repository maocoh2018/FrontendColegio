import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-componente4',
  templateUrl: './componente4.component.html',
  styleUrls: ['./componente4.component.css']
})
export class Componente4Component implements OnInit {
  public data:any = [];
  datos:any=[];

  displayedColumns: string[] = ['nombres', 'patrouns', 'age'];
  dataSource:any=[];
  mostrar:boolean=false;


  constructor() { }

  ngOnInit(): void {
    this.cargarUsuariosNuevos();
  }
  cargarUsuariosNuevos() {
    
    this.data = sessionStorage.getItem('usuarios');
    
    if(this.data === null){
      this.data = [];
    }else{
      this.datos = JSON.parse(this.data);
    }
    this.dataSource = this.datos;  
    this.mostrar = true;   

  }
}
