import { Component, OnInit } from '@angular/core';
import { CommonService } from 'src/app/services/common.service';
import { finalize } from 'rxjs/operators';

export interface PeriodicElement {
  id: number;
  casa: string;  
}

const ELEMENT_DATA: PeriodicElement[] = [
  {id: 1, casa: 'slytherin'},
  {id: 1, casa: 'gryffindor'},
  {id: 1, casa: 'ravenclaw'},
  {id: 1, casa: 'hufflepuff'},
];

@Component({
  selector: 'app-componente1',
  templateUrl: './componente1.component.html',
  styleUrls: ['./componente1.component.css']
})
export class Componente1Component implements OnInit {

  displayedColumns: string[] = ['name', 'patronus', 'dateOfBirth', 'image'];
  dataSource = ELEMENT_DATA;
  listaCasas:any=[];
  mostrar:boolean=false;

  constructor(
    private commonService: CommonService,
    
  ) { }

  ngOnInit() {
    this.listaCasas= ELEMENT_DATA;
    
}

cargarPersonajes(tipoCasa:string){
  //alert("entro");
  this.obtenerDatos(tipoCasa);
}

  obtenerDatos(tipoCasa:string) {

    this.commonService.obtenerDatosPersonajes(tipoCasa).pipe(
      finalize(() => {
        console.log('Servicio completado correctamente');        
      }
      )).subscribe(resp => {        
        this.dataSource = resp;  
        this.mostrar = true;   
        //console.log(this.dataSource);
      });
  }

}
